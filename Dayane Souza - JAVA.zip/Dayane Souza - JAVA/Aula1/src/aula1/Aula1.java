/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package aula1;

/**
 *
 * @author Aluno 05
 */
public class Aula1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("Hello World! Meu primeiro programa.");
        int atual = 2025;
      
        int nascimento = 1991;
        System.out.println("Sua idade e "+(atual-nascimento));
        double total = 10/3;
        System.out.println ("Total da conta "+ total);
              
    }
    
}
