/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package aula02;

/**
 *
 * @author Aluno 05
 */
public class Aula02 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int a=2, b=9;
       double resultado;
       resultado = a+b;
       System.out.println(a+"+"+b+"="+resultado);
       resultado = a-b;
       System.out.println(a+"-"+b+"="+resultado);
       resultado = a*b;
       System.out.println(a+"*"+b+"="+resultado);
       resultado = (double) a / (double) b;
       System.out.printf("%d / %d = %.2f %n", a, b, resultado);
       
       String nome = "Pedro";
       int idade = 18;
       System.out.printf("Bem vindo %s %nIdade: %d", nome, idade);
       
    }
    
}
