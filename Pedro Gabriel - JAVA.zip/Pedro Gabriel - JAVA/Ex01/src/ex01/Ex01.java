/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ex01;

import java.util.Scanner;

/**
 *
 * @author Aluno 05
 */
public class Ex01 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        double b, B, h, area;
        Scanner ler = new Scanner(System.in);
        System.out.println(x:"Digite o valor da Base (B):");
        B = ler.nextDouble();
        System.out.println(x:"Digite o valor da Base (b):");
        b = ler.nextDouble();
        System.out.println(x:"Digite o valor da Base (h):");
        h = ler.nextDouble();
        area = (b+B) / 2.0 * h;
        
        System.out.println("Area = "+ area);
        
        
    }
    
}
