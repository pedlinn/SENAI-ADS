/*link da api que será consumida*/
const api = "http://localhost:3000/produtos";

/*pegando elemento do html que vai receber dados*/
let tabela = document.getElementById("tabela");

/*função que os produtos*/
function buscaProduto(){
    fetch(api).then(
        response => {
            return response.json();
        }
    ).then(
        data =>{
            //console.log(data);
            data.forEach(produto => {
                tabela.innerHTML += `
                <tr>
                    <td>${produto.id}</td>
                    <td>${produto.nome}</td>
                    <td>${produto.descricao}</td>
                    <td>${produto.valor}</td>
                </tr>
                `
            });
        }
    )
}

/*chamando a função criada acima*/
buscaProduto();