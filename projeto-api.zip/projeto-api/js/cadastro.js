const api = "http://localhost:3000/produtos";

function cadastro(){
    let nome = document.getElementById("nome").value;
    let descricao = document.getElementById("descricao").value;
    let valor = document.getElementById("valor").value;

    const novoProduto = {
        nome: nome,
        descricao:descricao,
        valor:valor
    }

    fetch(api, {
        method:"POST",
        headers:{
            "Content-Type":"application/json"
        },
        body:JSON.stringify(novoProduto)
    })
    .then((response)=>{
        if(response.ok){
            alert("Cadastro efetuado com sucesso!");
            window.location = "index.html";
        }else{
            alert("Erro ao cadastrar");
        }
    })
}
document.getElementById("cadastrar").addEventListener("click", cadastro);
